To run this code file in linux, you need to install jupyter lab and these packages:
numpy,pandas,scikit-learn (sklearn),TextBlob
You can use these orders to install them:
pip install numpy
pip install pandas
pip install scikit-learn
pip install textblob

You can also copy the code into a py file and run it.
The dataset is  originally placed under the same root as the ipynb file. If you move the root, you need to change the path in the code.

All the code in ipynb file:

import os
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
from sklearn.preprocessing import StandardScaler
from textblob import TextBlob

# Define a function to read data
def load_data(base_directory):
    data = []
    labels = []
    categories = ['business', 'tech', 'sport', 'politics', 'entertainment']
    for category in categories:
        directory = os.path.join(base_directory, category)
        for filename in os.listdir(directory):
            filepath = os.path.join(directory, filename)
            if filepath.endswith(".txt"):
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as file:
                    text = file.read()
                    data.append(text)
                    labels.append(category)
    return data, labels

# Add a function to calculate document length and sentiment score
def feature_engineering(data):
    lengths = [len(text.split()) for text in data]  # Document length
    sentiments = [TextBlob(text).sentiment.polarity for text in data]  # Sentiment score
    return np.array(lengths), np.array(sentiments)

# Load data
current_directory = '.'  # Current working directory
data, labels = load_data(current_directory)

# Feature extraction
vectorizer = TfidfVectorizer(stop_words='english', max_features=1000)
tfidf_features = vectorizer.fit_transform(data)
lengths, sentiments = feature_engineering(data)

# Merge all features into one large feature matrix
features = np.hstack((tfidf_features.toarray(), lengths[:, np.newaxis], sentiments[:, np.newaxis]))

# Normalize features
scaler = StandardScaler()
features_scaled = scaler.fit_transform(features)

# Encode labels
y = pd.factorize(labels)[0]

# Split testset
X_train, X_test, y_train, y_test = train_test_split(features_scaled, y, test_size=0.2, random_state=42)

# Train using a Random Forest model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)
predictions = model.predict(X_test)

# Print classification report
print(classification_report(y_test, predictions, target_names=pd.unique(labels)))
